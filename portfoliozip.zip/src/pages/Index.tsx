import { HeroSection } from "@/components/portfolio/HeroSection";
import { AboutSection } from "@/components/portfolio/AboutSection";
import { ProjectsSection } from "@/components/portfolio/ProjectsSection";
import { ExperienceSection } from "@/components/portfolio/ExperienceSection";
import { EnquirySection } from "@/components/portfolio/EnquirySection";
import { Navigation } from "@/components/portfolio/Navigation";
import { Footer } from "@/components/portfolio/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      
      <main>
        <div id="hero">
          <HeroSection />
        </div>
        
        <AboutSection />
        <ProjectsSection />
        <ExperienceSection />
        <EnquirySection />
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;