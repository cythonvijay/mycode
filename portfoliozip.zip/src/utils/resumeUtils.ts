export const generateResumePDF = async () => {
  // Create a link to download the actual resume PDF
  const link = document.createElement('a');
  link.href = '/Vijay_Resume.pdf';
  link.download = 'Vijay_Pandiselvam_Resume.pdf';
  link.click();
};