import { useState } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ExternalLink, Figma, Eye } from "lucide-react";

const projects = [
  {
    id: 1,
    title: "TASTY TABLE",
    subtitle: "E-Commerce Food App",
    description: "A comprehensive food delivery app design with intuitive user interface and seamless ordering experience. Features include restaurant browsing, menu selection, cart management, and order tracking.",
    image: "/tasty-table-project.jpg",
    technologies: ["Figma", "UI/UX Design", "Prototyping", "User Research"],
    category: "Mobile App",
    link: "https://www.figma.com/proto/5Mm1a3XwCKK5Kazpjhgiui?node-id=0-1&t=CBiEZ6m37QEfx6Pn-6",
    details: "Created a complete food delivery app experience from user research to final prototype. Conducted usability testing and implemented feedback to optimize the user journey."
  },
  {
    id: 2,
    title: "SHOP IT",
    subtitle: "E-Commerce Website",
    description: "Modern e-commerce platform design with focus on user experience and conversion optimization. Includes product catalog, shopping cart, checkout process, and user account management.",
    image: "/shop-it-project.jpg",
    technologies: ["Figma", "UI/UX Design", "E-commerce", "Web Design"],
    category: "Website",
    link: "https://www.figma.com/proto/IZalFpxlItbb6WtojOrA0M?node-id=0-1&t=e4WyYculnewobqrI-6",
    details: "Designed a complete e-commerce solution with emphasis on mobile-first approach and accessibility. Implemented modern design trends while maintaining usability."
  },
  {
    id: 3,
    title: "UNCHAINED",
    subtitle: "Gym Landing Page",
    description: "Dynamic and powerful landing page design for a fitness gym brand. Features bold visuals, membership showcases, and motivating call-to-action elements to drive sign-ups.",
    image: "/unchained-gym-project.jpg",
    technologies: ["Figma", "Landing Page", "Fitness Branding", "UI Design"],
    category: "Landing Page",
    link: "https://www.figma.com/proto/NmRpBed1mkr7iYqswfUR8N?node-id=0-1&t=SnuaID104XH8ZeQJ-6",
    details: "Designed an energetic gym landing page that captures the intensity and motivation of fitness culture. Focused on bold typography, powerful imagery, and seamless user journey to convert visitors into members."
  },
  {
    id: 4,
    title: "FINTECH Dashboard",
    subtitle: "Financial Dashboard",
    description: "Comprehensive fintech dashboard with real-time data visualization, transaction management, and portfolio tracking.",
    image: "/fintech-dashboard-project.jpg",
    technologies: ["Figma", "Dashboard Design", "Data Visualization", "Fintech"],
    category: "Dashboard",
    link: "https://www.figma.com/design/TNAAGz0xmI1LsTsPQoqvIH/Untitled?node-id=0-1&p=f&t=Ds7QJreBlqWplyQy-0",
    details: "Developed a sophisticated financial dashboard that simplifies complex data into actionable insights. Includes advanced charting, account management, and transaction history."
  }
];

export const ProjectsSection = () => {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true
  });

  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <section id="projects" className="py-20 px-6 bg-glass" ref={ref}>
      <div className="container mx-auto">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="space-y-16"
        >
          {/* Header */}
          <motion.div variants={itemVariants} className="text-center space-y-4">
            <h2 className="text-4xl lg:text-5xl font-bold text-foreground">
              Featured <span className="bg-accent-gradient bg-clip-text text-transparent">Projects</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Immersive Experiences Unveiled
            </p>
          </motion.div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                variants={itemVariants}
                whileHover={{ 
                  y: -10,
                  transition: { duration: 0.3 }
                }}
                className="group"
              >
                <Card className="bg-card-gradient border-glass-border shadow-card hover:shadow-glow-primary/20 transition-all duration-500 overflow-hidden h-full">
                  <div className="relative overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <Button
                        onClick={() => setSelectedProject(project)}
                        className="bg-primary hover:bg-primary/90 text-primary-foreground transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300"
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </Button>
                    </div>
                  </div>
                  
                  <CardContent className="p-6 space-y-4">
                    <div className="space-y-2">
                      <Badge className="bg-primary/10 text-primary border-primary/20">
                        {project.category}
                      </Badge>
                      <h3 className="text-xl font-bold text-foreground">{project.title}</h3>
                      <p className="text-primary font-medium">{project.subtitle}</p>
                    </div>
                    
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {project.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech, techIndex) => (
                        <Badge 
                          key={techIndex} 
                          variant="secondary"
                          className="bg-glass border-glass-border text-xs"
                        >
                          {tech}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        size="sm" 
                        className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                        onClick={() => setSelectedProject(project)}
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        Details
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                        asChild
                      >
                        <a href={project.link} target="_blank" rel="noopener noreferrer">
                          <Figma className="w-4 h-4 mr-2" />
                          View
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Project Modal */}
      <Dialog open={!!selectedProject} onOpenChange={() => setSelectedProject(null)}>
        {selectedProject && (
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-card border-glass-border">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold text-foreground">
                {selectedProject.title}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6">
              <img 
                src={selectedProject.image} 
                alt={selectedProject.title}
                className="w-full h-64 object-cover rounded-lg"
              />
              
              <div className="space-y-4">
                <div>
                  <Badge className="bg-primary/10 text-primary border-primary/20 mb-2">
                    {selectedProject.category}
                  </Badge>
                  <h3 className="text-xl font-bold text-foreground">{selectedProject.subtitle}</h3>
                </div>
                
                <p className="text-muted-foreground leading-relaxed">
                  {selectedProject.details}
                </p>
                
                <div className="space-y-3">
                  <h4 className="font-semibold text-foreground">Technologies Used:</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject.technologies.map((tech, index) => (
                      <Badge 
                        key={index} 
                        variant="secondary"
                        className="bg-glass border-glass-border"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <Button 
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mt-6"
                  asChild
                >
                  <a href={selectedProject.link} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View Project on Figma
                  </a>
                </Button>
              </div>
            </div>
          </DialogContent>
        )}
      </Dialog>
    </section>
  );
};