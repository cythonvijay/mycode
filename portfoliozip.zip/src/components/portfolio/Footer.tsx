import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowUp, Heart, Mail, Linkedin, Instagram } from "lucide-react";

const socialLinks = [
  {
    icon: Mail,
    href: "mailto:vijaynisha343@gmail.com",
    label: "Email"
  },
  {
    icon: Linkedin,
    href: "https://www.linkedin.com/in/vijay-p-6b7315280/",
    label: "LinkedIn"
  },
  {
    icon: Instagram,
    href: "https://instagram.com/graphix_artz",
    label: "Instagram"
  }
];

const quickLinks = [
  { name: "About", href: "#about" },
  { name: "Projects", href: "#projects" },
  { name: "Experience", href: "#experience" },
  { name: "Contact", href: "#contact" },
];

export const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const scrollToSection = (href: string) => {
    const sectionId = href.substring(1);
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-hero-gradient border-t border-glass-border">
      <div className="container mx-auto px-6">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div className="lg:col-span-2 space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
              >
                <h3 className="text-2xl font-bold text-foreground mb-4">
                  <span className="bg-accent-gradient bg-clip-text text-transparent">
                    Vijay Pandiselvam
                  </span>
                </h3>
                <p className="text-muted-foreground leading-relaxed max-w-md">
                  UI/UX Designer passionate about creating exceptional digital experiences. 
                  Let's collaborate to bring your ideas to life with beautiful, functional design.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                viewport={{ once: true }}
                className="flex gap-4"
              >
                {socialLinks.map((social, index) => (
                  <motion.a
                    key={index}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.1, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-10 h-10 rounded-full bg-glass border border-glass-border hover:bg-primary hover:text-primary-foreground transition-all duration-300 flex items-center justify-center group"
                    aria-label={social.label}
                  >
                    <social.icon className="w-4 h-4" />
                  </motion.a>
                ))}
              </motion.div>
            </div>

            {/* Quick Links */}
            <div className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <h4 className="text-lg font-semibold text-foreground mb-4">Quick Links</h4>
                <ul className="space-y-2">
                  {quickLinks.map((link, index) => (
                    <li key={index}>
                      <button
                        onClick={() => scrollToSection(link.href)}
                        className="text-muted-foreground hover:text-primary transition-colors duration-200 text-sm"
                      >
                        {link.name}
                      </button>
                    </li>
                  ))}
                </ul>
              </motion.div>
            </div>

            {/* Contact Info */}
            <div className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                viewport={{ once: true }}
              >
                <h4 className="text-lg font-semibold text-foreground mb-4">Get In Touch</h4>
                <div className="space-y-3">
                  <a
                    href="mailto:vijaynisha343@gmail.com"
                    className="block text-muted-foreground hover:text-primary transition-colors duration-200 text-sm"
                  >
                    vijaynisha343@gmail.com
                  </a>
                  <a
                    href="https://www.linkedin.com/in/vijay-p-6b7315280/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-muted-foreground hover:text-primary transition-colors duration-200 text-sm"
                  >
                    LinkedIn Profile
                  </a>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="py-6 border-t border-glass-border">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-muted-foreground text-sm text-center md:text-left"
            >
              © 2024 Vijay Pandiselvam. Made with{" "}
              <Heart className="inline w-4 h-4 text-red-500 mx-1" />{" "}
              and passion for great design.
            </motion.p>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <Button
                onClick={scrollToTop}
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-primary hover:bg-glass transition-all duration-300 group"
              >
                <span className="mr-2 text-xs">Back to Top</span>
                <ArrowUp className="w-3 h-3 group-hover:-translate-y-1 transition-transform duration-300" />
              </Button>
            </motion.div>
          </div>
        </div>
      </div>
    </footer>
  );
};