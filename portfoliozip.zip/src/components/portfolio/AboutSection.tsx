import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

const skills = [
  { name: "UI/UX Design", level: 95 },
  { name: "JavaScript", level: 85 },
  { name: "Python", level: 65 },
  { name: "IoT and Embedded Systems", level: 75 },
  { name: "Figma", level: 95 },
  { name: "HTML/CSS", level: 92 },
  { name: "Project Management", level: 80 },
];

const certifications = [
  "Fundamentals of UI/UX Design Course - Microsoft, Coursera",
  "Engineering and Product Design Process - Arizona State University, Coursera",
  "Responsive Web Design - FreeCodeCamp",
  "NPTEL Computer Graphics Course - IIT Guwahati",
  "Digital Skills: User Experience - Accenture"
];

const expertise = [
  "UI/UX Designer",
  "Full Stack Development (JavaScript)",
  "Python (Intermediate)",
  "SQL Basic Knowledge",
  "Project Management",
  "Leadership and Management"
];

export const AboutSection = () => {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <section id="about" className="py-20 px-6" ref={ref}>
      <div className="container mx-auto">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="space-y-16"
        >
          {/* Header */}
          <motion.div variants={itemVariants} className="text-center space-y-4">
            <h2 className="text-4xl lg:text-5xl font-bold text-foreground">
              About <span className="bg-accent-gradient bg-clip-text text-transparent">Me</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              My Design Journey and Expertise
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left - Philosophy & Info */}
            <motion.div variants={itemVariants} className="space-y-8">
              <Card className="bg-card-gradient border-glass-border shadow-card">
                <CardContent className="p-8 space-y-6">
                  <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full"></span>
                    Design Philosophy
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    I believe that design is not just about aesthetics; it's about solving problems, 
                    simplifying complexity, and creating seamless interactions. Every project I undertake 
                    is guided by this principle, ensuring that users not only enjoy using the product 
                    but find it genuinely helpful.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-card-gradient border-glass-border shadow-card">
                <CardContent className="p-8 space-y-6">
                  <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                    <span className="w-2 h-2 bg-accent rounded-full"></span>
                    Education
                  </h3>
                  <p className="text-muted-foreground">
                    <strong>Bachelor of Computer Science Engineering</strong><br />
                    Anna University • CGPA: 8.0
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-card-gradient border-glass-border shadow-card">
                <CardContent className="p-8 space-y-6">
                  <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                    <span className="w-2 h-2 bg-secondary rounded-full"></span>
                    Key Expertise
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {expertise.map((skill, index) => (
                      <Badge 
                        key={index} 
                        variant="secondary" 
                        className="bg-glass border-glass-border text-foreground hover:bg-primary hover:text-primary-foreground transition-all duration-300"
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Right - Skills */}
            <motion.div variants={itemVariants} className="space-y-8">
              <Card className="bg-card-gradient border-glass-border shadow-card">
                <CardContent className="p-8 space-y-6">
                  <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full animate-pulse"></span>
                    Technical Skills
                  </h3>
                  <div className="space-y-6">
                    {skills.map((skill, index) => (
                      <motion.div
                        key={skill.name}
                        initial={{ opacity: 0, x: -20 }}
                        animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
                        transition={{ delay: index * 0.1, duration: 0.6 }}
                        className="space-y-2"
                      >
                        <div className="flex justify-between items-center">
                          <span className="text-foreground font-medium">{skill.name}</span>
                          <span className="text-primary font-bold">{skill.level}%</span>
                        </div>
                        <Progress 
                          value={inView ? skill.level : 0} 
                          className="h-3 bg-muted"
                        />
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card-gradient border-glass-border shadow-card">
                <CardContent className="p-8 space-y-6">
                  <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                    <span className="w-2 h-2 bg-accent rounded-full animate-pulse"></span>
                    Certifications
                  </h3>
                  <div className="space-y-3">
                    {certifications.map((cert, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
                        transition={{ delay: index * 0.1, duration: 0.4 }}
                        className="flex items-start gap-3 p-3 rounded-lg bg-glass border border-glass-border hover:border-primary/30 transition-all duration-300"
                      >
                        <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                        <span className="text-muted-foreground text-sm leading-relaxed">{cert}</span>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};