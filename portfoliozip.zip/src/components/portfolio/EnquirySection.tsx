import { useState } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Mail, Send, CheckCircle, Users, Lightbulb } from "lucide-react";

export const EnquirySection = () => {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true
  });

  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setIsSubmitting(true);

  try {
    const submissionData = {
      ...formData,
      access_key: "6b406dfe-5b48-4718-ae04-c2e469a26e3e"
    };

    const response = await fetch("https://api.web3forms.com/submit", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(submissionData),
    });

    const result = await response.json();

    if (result.success) {
      toast({
        title: "Enquiry Sent Successfully!",
        description: "Thank you for reaching out. I'll get back to you soon!",
      });

      setFormData({ name: "", email: "", company: "", message: "" });
    } else {
      throw new Error(result.message);
    }

  } catch (error: any) {
    console.error("Error sending enquiry:", error);
    toast({
      title: "Failed to Send Enquiry",
      description: "Please try again or contact me directly at vijaynisha343@gmail.com",
      variant: "destructive",
    });
  } finally {
    setIsSubmitting(false);
  }
};

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <section id="enquiry" className="py-20 px-6 bg-gradient-to-br from-background to-muted/20" ref={ref}>
      <div className="container mx-auto">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="space-y-16"
        >
          {/* Header */}
          <motion.div variants={itemVariants} className="text-center space-y-6">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Users className="w-8 h-8 text-primary" />
              </div>
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold text-foreground">
              Let's <span className="bg-accent-gradient bg-clip-text text-transparent">Connect Together</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Have a project in mind? Let's collaborate and create something amazing together. 
              I'm always excited to work on new challenges and bring creative ideas to life.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Info Cards */}
            <motion.div variants={itemVariants} className="space-y-6">
              <Card className="bg-card-gradient border-glass-border shadow-card overflow-hidden group hover:shadow-card-hover transition-all duration-300">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                      <Lightbulb className="w-6 h-6" />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-xl font-bold text-foreground">Creative Collaboration</h3>
                      <p className="text-muted-foreground leading-relaxed">
                        I believe the best designs come from understanding your vision and combining it with 
                        user-centered design principles to create exceptional experiences.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card-gradient border-glass-border shadow-card overflow-hidden group hover:shadow-card-hover transition-all duration-300">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center group-hover:bg-accent group-hover:text-accent-foreground transition-all duration-300">
                      <Mail className="w-6 h-6" />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-xl font-bold text-foreground">Quick Response</h3>
                      <p className="text-muted-foreground leading-relaxed">
                        I typically respond to enquiries within 24 hours. Let's discuss your project 
                        requirements and how we can work together to achieve your goals.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Contact Info */}
              <motion.div
                variants={itemVariants}
                className="relative p-8 rounded-lg bg-accent-gradient text-accent-foreground overflow-hidden"
              >
                <div className="relative z-10 space-y-4">
                  <h4 className="text-xl font-bold">Ready to Start?</h4>
                  <p className="text-sm opacity-90 leading-relaxed">
                    Fill out the form and I'll get back to you with ideas on how we can 
                    make your project stand out from the competition.
                  </p>
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="w-4 h-4" />
                    <span>vijaynisha343@gmail.com</span>
                     <form><input type="checkbox" name="botcheck" className="hidden" /></form>
                  </div>
                </div>
                
                <motion.div 
                  className="absolute top-4 right-4 w-16 h-16 rounded-full bg-white/20"
                  animate={{ 
                    scale: [1, 1.2, 1],
                    opacity: [0.5, 0.8, 0.5],
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                />
              </motion.div>
            </motion.div>

            {/* Enquiry Form */}
            <motion.div variants={itemVariants}>
              <Card className="bg-card-gradient border-glass-border shadow-card">
                <CardContent className="p-8">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
                        transition={{ delay: 0.1, duration: 0.4 }}
                      >
                        <Input
                          name="name"
                          placeholder="Your Name"
                          value={formData.name}
                          onChange={handleInputChange}
                          required
                          className="bg-background/90 border-border focus:border-primary transition-colors text-foreground placeholder:text-muted-foreground"
                        />
                      </motion.div>
                      
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                        transition={{ delay: 0.2, duration: 0.4 }}
                      >
                        <Input
                          name="email"
                          type="email"
                          placeholder="Your Email"
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                          className="bg-background/90 border-border focus:border-primary transition-colors text-foreground placeholder:text-muted-foreground"
                        />
                      </motion.div>
                    </div>

                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                      transition={{ delay: 0.3, duration: 0.4 }}
                    >
                      <Input
                        name="company"
                        placeholder="Company/Organization (Optional)"
                        value={formData.company}
                        onChange={handleInputChange}
                        className="bg-background/90 border-border focus:border-primary transition-colors text-foreground placeholder:text-muted-foreground"
                      />
                    </motion.div>

                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                      transition={{ delay: 0.4, duration: 0.4 }}
                    >
                      <Textarea
                        name="message"
                        placeholder="Tell me about your project, timeline, and budget..."
                        value={formData.message}
                        onChange={handleInputChange}
                        required
                        rows={6}
                        className="bg-background/90 border-border focus:border-primary transition-colors resize-none text-foreground placeholder:text-muted-foreground"
                      />
                    </motion.div>

                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                      transition={{ delay: 0.5, duration: 0.4 }}
                    >
                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-glow-primary hover:shadow-glow-primary/70 transition-all duration-300 h-12"
                      >
                        {isSubmitting ? (
                          <div className="flex items-center gap-2">
                            <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin"></div>
                            Sending Enquiry...
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <Send className="w-4 h-4" />
                            Send Enquiry
                          </div>
                          
                        )}
                      </Button>
                    </motion.div>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};