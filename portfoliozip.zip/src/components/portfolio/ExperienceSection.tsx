import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, MapPin, Building } from "lucide-react";

const experiences = [
  {
    id: 1,
    company: "Zaalima Development",
    role: "UI/UX Designer",
    duration: "3 Months",
    type: "Virtual Internship",
    location: "Remote",
    description: "Worked on fintech dashboard design and various UI/UX projects. Collaborated with development teams to create user-centered designs.",
    achievements: [
      "Designed comprehensive fintech dashboard interface",
      "Created wireframes and prototypes for multiple projects",
      "Collaborated with cross-functional teams",
      "Improved user experience through data-driven design decisions"
    ],
    technologies: ["Figma", "UI/UX Design", "Fintech", "Dashboard Design"]
  },
  {
    id: 3,
    company: "UPTOSKILLS",
    role: "UI/UX Designer", 
    duration: "3 Months",
    type: "Virtual Internship",
    location: "Remote",
    description: "Led the complete redesign of Uptoskills website, focusing on user experience improvement and modern design principles.",
    achievements: [
      "Redesigned entire Uptoskills website",
      "Conducted user research and usability testing",
      "Implemented responsive design principles",
      "Increased user engagement through improved UX"
    ],
    technologies: ["Figma", "Web Design", "User Research", "Prototyping"]
  },
  {
    id: 4,
    company: "CODSOFT",
    role: "UI/UX Designer",
    duration: "1 Month", 
    type: "Virtual Internship",
    location: "Remote",
    description: "Developed UI/UX designs for Student Learn project, focusing on educational platform design and user experience optimization.",
    achievements: [
      "Designed Student Learn educational platform",
      "Created user-friendly learning interfaces",
      "Developed design systems and components",
      "Enhanced accessibility and usability"
    ],
    technologies: ["Figma", "Educational Design", "UI Components", "User Experience"]
  },
  {
    id: 5,
    company: "VITAL SKILLS",
    role: "UI/UX Designer",
    duration: "1 Month",
    type: "Virtual Internship", 
    location: "Remote",
    description: "Designed Shop It E-Commerce website with focus on modern e-commerce user experience and conversion optimization.",
    achievements: [
      "Created complete e-commerce website design",
      "Optimized checkout and user flow processes",
      "Designed responsive mobile interfaces",
      "Improved conversion rates through UX optimization"
    ],
    technologies: ["Figma", "E-commerce Design", "Mobile UI", "Conversion Optimization"]
  }
];

const activities = [
  "Conducted UI/UX Design webinar for department students",
  "Participated in Tata Campus Quiz 2024",
  "President of Department Club 'FORZA'",
  "Student Coordinator of ELITE Community from FORZA",
  "Completed job simulations through Forage (Product Design, Project Management from Accenture)",
  "Junior Typist Certification from Government of Tamil Nadu with First Class"
];

export const ExperienceSection = () => {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -50 },
    visible: { opacity: 1, x: 0 }
  };

  return (
    <section id="experience" className="py-20 px-6" ref={ref}>
      <div className="container mx-auto">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="space-y-16"
        >
          {/* Header */}
          <motion.div variants={itemVariants} className="text-center space-y-4">
            <h2 className="text-4xl lg:text-5xl font-bold text-foreground">
              Experience & <span className="bg-accent-gradient bg-clip-text text-transparent">Journey</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              My professional growth and internship experiences
            </p>
          </motion.div>

          {/* Timeline */}
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-accent to-secondary"></div>
            
            <div className="space-y-12">
              {experiences.map((experience, index) => (
                <motion.div
                  key={experience.id}
                  variants={itemVariants}
                  className="relative flex gap-8"
                >
                  {/* Timeline Node */}
                  <div className="relative z-10 flex-shrink-0">
                    <motion.div 
                      className="w-16 h-16 rounded-full bg-card-gradient border-4 border-primary shadow-glow-primary flex items-center justify-center"
                      whileHover={{ scale: 1.1 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Building className="w-6 h-6 text-primary" />
                    </motion.div>
                  </div>

                  {/* Content */}
                  <Card className="flex-1 bg-card-gradient border-glass-border shadow-card hover:shadow-glow-primary/10 transition-all duration-300">
                    <CardContent className="p-8">
                      <div className="space-y-6">
                        <div className="space-y-3">
                          <div className="flex flex-wrap items-center gap-3">
                            <Badge className="bg-primary/10 text-primary border-primary/20">
                              {experience.type}
                            </Badge>
                            <div className="flex items-center gap-1 text-muted-foreground text-sm">
                              <CalendarDays className="w-4 h-4" />
                              {experience.duration}
                            </div>
                            <div className="flex items-center gap-1 text-muted-foreground text-sm">
                              <MapPin className="w-4 h-4" />
                              {experience.location}
                            </div>
                          </div>
                          
                          <h3 className="text-2xl font-bold text-foreground">{experience.role}</h3>
                          <p className="text-xl text-primary font-semibold">{experience.company}</p>
                        </div>

                        <p className="text-muted-foreground leading-relaxed">
                          {experience.description}
                        </p>

                        <div className="space-y-3">
                          <h4 className="font-semibold text-foreground">Key Achievements:</h4>
                          <ul className="space-y-2">
                            {experience.achievements.map((achievement, achIndex) => (
                              <li key={achIndex} className="flex items-start gap-3">
                                <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                                <span className="text-muted-foreground text-sm">{achievement}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          {experience.technologies.map((tech, techIndex) => (
                            <Badge 
                              key={techIndex}
                              variant="secondary"
                              className="bg-glass border-glass-border text-xs"
                            >
                              {tech}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Activities Section */}
          <motion.div variants={itemVariants} className="space-y-8">
            <h3 className="text-3xl font-bold text-center text-foreground">
              Leadership & <span className="bg-accent-gradient bg-clip-text text-transparent">Activities</span>
            </h3>
            
            <Card className="bg-card-gradient border-glass-border shadow-card">
              <CardContent className="p-8">
                <div className="grid md:grid-cols-2 gap-6">
                  {activities.map((activity, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                      transition={{ delay: index * 0.1, duration: 0.4 }}
                      className="flex items-start gap-3 p-4 rounded-lg bg-glass border border-glass-border hover:border-primary/30 transition-all duration-300"
                    >
                      <div className="w-2 h-2 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-muted-foreground text-sm leading-relaxed">{activity}</span>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};