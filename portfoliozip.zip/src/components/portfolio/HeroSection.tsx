import { motion } from "framer-motion";
import { TypeAnimation } from "react-type-animation";
import { Button } from "@/components/ui/button";
import { ArrowDown, Instagram, Linkedin, Mail, Download } from "lucide-react";
import { generateResumePDF } from "@/utils/resumeUtils";
import heroAvatar from "@/assets/hero-avatar.jpg";

export const HeroSection = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offsetTop = element.offsetTop - 80; // Account for fixed header
      window.scrollTo({ top: offsetTop, behavior: "smooth" });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-hero-gradient">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div 
          className="absolute top-20 left-20 w-72 h-72 bg-primary/20 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{ duration: 4, repeat: Infinity }}
        />
        <motion.div 
          className="absolute bottom-20 right-20 w-96 h-96 bg-accent/20 rounded-full blur-3xl"
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.4, 0.7, 0.4],
          }}
          transition={{ duration: 5, repeat: Infinity }}
        />
        <motion.div 
          className="absolute top-1/2 left-1/2 w-64 h-64 bg-secondary/15 rounded-full blur-2xl"
          animate={{ 
            x: [-50, 50, -50],
            y: [-30, 30, -30],
          }}
          transition={{ duration: 6, repeat: Infinity }}
        />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <motion.div 
            className="space-y-8"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div 
              className="space-y-4"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              <p className="text-primary text-lg font-medium">Hello, I'm</p>
              <h1 className="text-5xl lg:text-7xl font-bold text-foreground">
                Vijay <span className="bg-accent-gradient bg-clip-text text-transparent">Pandiselvam</span>
              </h1>
            </motion.div>

            <div className="text-2xl lg:text-3xl text-muted-foreground font-light">
              <TypeAnimation
                sequence={[
                  'UI/UX Designer',
                  2000,
                  'Full Stack Developer',
                  2000,
                  'Creative Problem Solver',
                  2000,
                ]}
                wrapper="span"
                speed={50}
                repeat={Infinity}
              />
            </div>

            <motion.p 
              className="text-lg text-muted-foreground max-w-lg leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              I design modern, interactive UI/UX experiences that solve problems, 
              simplify complexity, and create seamless user interactions.
            </motion.p>

            <motion.div 
              className="flex flex-wrap gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.8 }}
            >
              <Button 
    size="lg" 
    className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-glow-primary hover:shadow-glow-primary/70 transition-all duration-300"
    onClick={() => scrollToSection('projects')}
  >
    View My Work
  </Button>

  {/* Scroll to Enquiry Section */}
  <Button 
    size="lg" 
    variant="outline" 
    className="border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300"
    onClick={() => scrollToSection('enquiry')}
  >
    Contact Me
  </Button>

  {/* Download Resume */}
  <Button 
    size="lg" 
    variant="outline" 
    className="border-accent text-accent hover:bg-accent hover:text-accent-foreground transition-all duration-300 group"
    onClick={generateResumePDF}
  >
    <Download className="w-4 h-4 mr-2 group-hover:translate-y-1 transition-transform duration-300" />
    Download Resume
  </Button>
            </motion.div>

            <motion.div 
              className="flex gap-4 pt-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.8 }}
            >
              <a 
                href="mailto:vijaynisha343@gmail.com"
                className="p-3 rounded-full bg-glass border border-glass-border hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-110"
              >
                <Mail className="w-5 h-5" />
              </a>
              <a 
                href="https://www.linkedin.com/in/vijay-p-6b7315280/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-full bg-glass border border-glass-border hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-110"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a 
                href="https://instagram.com/graphix_artz"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-full bg-glass border border-glass-border hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-110"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </motion.div>
          </motion.div>

          {/* Photo Section */}
          <motion.div 
            className="relative flex justify-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            <motion.div 
              className="relative w-80 h-80 lg:w-96 lg:h-96"
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            >
              <img 
                src={heroAvatar} 
                alt="Vijay Pandiselvam" 
                className="absolute inset-0 w-full h-full object-cover rounded-full border-4 border-primary/30 shadow-glow-primary"
              />
              <motion.div 
                className="absolute -inset-4 rounded-full border border-primary/20"
                animate={{ rotate: -360 }}
                transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
              />
              <motion.div 
                className="absolute -inset-8 rounded-full border border-accent/10"
                animate={{ rotate: 360 }}
                transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
              />
            </motion.div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
        >
          <motion.button
            onClick={() => scrollToSection('about')}
            className="flex flex-col items-center gap-2 text-muted-foreground hover:text-primary transition-colors group"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <span className="text-sm">Scroll Down</span>
            <ArrowDown className="w-5 h-5 group-hover:text-primary transition-colors" />
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};